import mysql.connector
from django.db.models import query
from mysql.connector import Error


def db_connection1(hostname, username, password):
    connection = None
    try:
        connection = mysql.connector.Connect(
            host=hostname,
            user=username,
            passwd=password

        )
        print("Connection to MySQL DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection


connection = db_connection1("localhost", "root", "Sandu@96")


def create_database(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        print("Database created successfully")
    except Error as e:
        print("The error '{e}' occurred")


create_database_query = "CREATE DATABASE databaseRP"
create_database(connection, create_database_query)
