import mysql.connector
from mysql.connector import Error
from dbCreation import db_connection, connection


def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")


create_person_table = """
CREATE TABLE IF NOT EXISTS person (
  pid INT AUTO_INCREMENT, 
  name TEXT NOT NULL,  
  description TEXT, 
  PRIMARY KEY (pid)
) ENGINE = InnoDB
"""
execute_query(connection, create_person_table)

create_time_table = """
CREATE TABLE IF NOT EXISTS time (
  tid INT AUTO_INCREMENT, 
  time TEXT NOT NULL,  
  description TEXT, 
  PRIMARY KEY (tid)
) ENGINE = InnoDB
"""
execute_query(connection, create_time_table)

create_location_table = """
CREATE TABLE IF NOT EXISTS location (
  lid INT AUTO_INCREMENT, 
  location TEXT NOT NULL,  
  description TEXT, 
  PRIMARY KEY (lid)
) ENGINE = InnoDB
"""
execute_query(connection, create_location_table)

create_art_table = """
CREATE TABLE IF NOT EXISTS art (
  aid INT AUTO_INCREMENT, 
  art TEXT NOT NULL,  
  description TEXT, 
  PRIMARY KEY (aid)
) ENGINE = InnoDB
"""
execute_query(connection, create_art_table)

create_person = """
INSERT INTO
  `person` (`name`, `description`)
VALUES
  ('රජතුමා','ඉතිහාසයේ රට පාලනය කළ පාලකයන්'),
  ('ජනාධිපති','රට පාලනය කරන පුද්ගලයා'),
  ('බිරිඳ','විවාහක කාන්තාව');
"""

execute_query(connection, create_person)

create_time = """
INSERT INTO
  `time` (`time`, `description`)
VALUES
  ('වර්ෂය','දින 365 ක කාලය'),
  ('කාලය','ක්‍රි.පූ 3 වන සියවස සහ ක්‍රි.ව. 1 වන සියවස අතර');
"""

execute_query(connection, create_time)

create_location = """
INSERT INTO
  `location` (`location`, `description`)
VALUES
  ('ස්ථානය','විශේෂිත ප්‍රදේශයක්'),
  ('නගරය','දඹුල්ල නගරය'),
  ('ප්‍රදේශය','මාතලේ දිස්ත්‍රික්කය');
"""

execute_query(connection, create_location)

create_art = """
INSERT INTO 
    `art` (`art`, `description`) 
VALUES 
    ('බිතු සිතුවම්','බිත්තියක් හෝ සිවිලිමක් මත තෙත් 
    ප්ලාස්ටර් මත ජල වර්ණක වේගයෙන් කරන ලද සිතුවමක් වන අතර එමඟින් වර්ණ ප්ලාස්ටර් තුලට විනිවිද ගොස් වියළන විට ස්ථාවර වේ.'), 
    ('ලෝක උරුමය','මානව වර්ගයාට කැපී පෙනෙන විශ්වීය වටිනාකමක් ඇති පෘථිවියේ ස්ථාන'), 
    ('උස','වස්තුවක පහළම කෙළවර සහ ඉහළම කෙළවර අතර දුර'); 
"""

execute_query(connection, create_art)

create_details_table = """
CREATE TABLE IF NOT EXISTS details (
  id INT AUTO_INCREMENT, 
  name TEXT NOT NULL,  
  description TEXT, 
  PRIMARY KEY (id)
) ENGINE = InnoDB
"""
execute_query(connection, create_details_table)

create_details = """
INSERT INTO
  `details` (`name`, `description`)
VALUES
  ('රජතුමා','ඉතිහාසයේ රට පාලනය කළ පාලකයන්'),
  ('ජනාධිපති','රට පාලනය කරන පුද්ගලයා'),
  ('බිරිඳ','විවාහක කාන්තාව'),
  ('වර්ෂය','දින 365 ක කාලය'),
  ('කාලය','ක්‍රි.පූ 3 වන සියවස සහ ක්‍රි.ව. 1 වන සියවස අතර'),
  ('ස්ථානය','විශේෂිත ප්‍රදේශයක්'),
  ('නගරය','දඹුල්ල නගරය'),
  ('ප්‍රදේශය','මාතලේ දිස්ත්‍රික්කය'),
  ('බිතු සිතුවම්','බිත්තියක් හෝ සිවිලිමක් මත තෙත් 
    ප්ලාස්ටර් මත ජල වර්ණක වේගයෙන් කරන ලද සිතුවමක් වන අතර එමඟින් වර්ණ ප්ලාස්ටර් තුලට විනිවිද ගොස් වියළන විට ස්ථාවර වේ.'), 
  ('ලෝක උරුමය','මානව වර්ගයාට කැපී පෙනෙන විශ්වීය වටිනාකමක් ඇති පෘථිවියේ ස්ථාන'), 
  ('උස','වස්තුවක පහළම කෙළවර සහ ඉහළම කෙළවර අතර දුර'); 

"""
execute_query(connection, create_details)