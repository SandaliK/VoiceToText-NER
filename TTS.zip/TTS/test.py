import mysql.connector
from django.db.models import query
from mysql.connector import Error


def db_connection(hostname, username, password, db1):
    connection = None
    try:
        connection = mysql.connector.Connect(
            host=hostname,
            user=username,
            passwd=password,
            database=db1

        )
        print("Connection to MySQL DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection


# connection = db_connection("localhost", "root", "Sandu@96", "databaseRP")

"""def create_database(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        print("Database created successfully")
    except Error as e:
        print("The error '{e}' occurred")


create_database_query = "CREATE DATABASE RP_DB"
create_database(connection, create_database_query)"""


"""def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")"""


"""def execute_read_query(connection, query):
    cursor = connection.cursor()
    result = None
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f"The error '{e}' occurred")"""


"""select_details = "SELECT * FROM details"
details = execute_read_query(connection, select_details)
print(details)"""


"""delete_person4 = "DELETE FROM person WHERE pid  = 16"
delete_person5 = "DELETE FROM person WHERE pid  = 17"
delete_person6 = "DELETE FROM person WHERE pid  = 18"

execute_query(connection, delete_person4)
execute_query(connection, delete_person5)
execute_query(connection, delete_person6)"""
