from gtts import gTTS
import os
from pydub import AudioSegment
from pydub.playback import play
import main

#text = "ගඩලින් තැනූ සිංහයාගේ රූප ඇඳ තිබෙන සීගිරි ලලනාවන්"


lan = "si"
tts = gTTS(text=text, lang=lan, slow=False)

output = "output.mp3"

tts.save(output)

sound = AudioSegment.from_mp3(output)
play(sound)



